./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u RYHpXzidh6djME9YiBmEe7QRpxQkeQQBST.hellminer -p hybrid --cpu 2
