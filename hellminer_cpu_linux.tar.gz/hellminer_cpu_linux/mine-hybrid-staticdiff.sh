./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u RYHpXzidh6djME9YiBmEe7QRpxQkeQQBST.hellminer -p d=16384s,hybrid --cpu 2
